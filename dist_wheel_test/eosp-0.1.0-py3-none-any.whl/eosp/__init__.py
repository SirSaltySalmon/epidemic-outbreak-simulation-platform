"""EOSP application package."""

